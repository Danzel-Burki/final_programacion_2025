<?php
// Incluir archivo de conexión a la base de datos
include('../includes/conexion.php');

// Variable para la búsqueda
$busqueda = '';
if (isset($_GET['buscar'])) {
    $busqueda = $_GET['buscar'];
}

// Preparamos la consulta SQL
$sql = "SELECT l.id_libro, l.titulo, l.anio_publicacion, l.genero
        FROM libros l
        JOIN asociado a ON l.id_libro = a.id_libro
        JOIN prestamo p ON a.id_prestamo = p.id_prestamo
        WHERE CAST(p.cantidad AS UNSIGNED) > 0 ";

if ($busqueda) {
    $sql .= "AND (l.titulo LIKE ? OR l.genero LIKE ?)";
}

$stmt = mysqli_prepare($conn, $sql);

// Si hay búsqueda, se asignan los valores de los parámetros
if ($busqueda) {
    $search_term = "%" . $busqueda . "%";
    mysqli_stmt_bind_param($stmt, "ss", $search_term, $search_term);
}

// Ejecutar la consulta
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Libros Disponibles</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h1>Consulta de Libros Disponibles</h1>
    
    <!-- Formulario de búsqueda -->
    <form method="GET" action="consultas_libros.php">
        <label for="buscar">Buscar por Título o Género:</label>
        <input type="text" name="buscar" id="buscar" value="<?= htmlspecialchars($busqueda) ?>">
        <input type="submit" value="Buscar">
    </form>

    <!-- Mostrar resultados -->
    <?php if (mysqli_num_rows($result) > 0): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>ID Libro</th>
                    <th>Título</th>
                    <th>Año de Publicación</th>
                    <th>Género</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id_libro']) ?></td>
                        <td><?= htmlspecialchars($row['titulo']) ?></td>
                        <td><?= htmlspecialchars($row['anio_publicacion']) ?></td>
                        <td><?= htmlspecialchars($row['genero']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No se encontraron libros disponibles.</p>
    <?php endif; ?>
</body>
</html>

<?php
// Cerrar la conexión
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
