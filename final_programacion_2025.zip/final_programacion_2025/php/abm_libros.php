<?php
include('../includes/conexion.php');

if (isset($_POST['accion'])) {
    $titulo = $_POST['titulo'] ?? '';
    $anio_publicacion = $_POST['anio_publicacion'] ?? '';
    $genero = $_POST['genero'] ?? '';
    $cantidad = $_POST['cantidad'] ?? '';
    $id_libro = $_POST['id_libro'] ?? '';

    if ($_POST['accion'] == 'alta') {
        // Insertar libro en la tabla libros
        $sql = $conn->prepare("INSERT INTO libros (titulo, anio_publicacion, genero, cantidad) VALUES (?, ?, ?, ?)");
        $sql->bind_param("sssi", $titulo, $anio_publicacion, $genero, $cantidad);
        $sql->execute();

        // Obtención del ID del libro recién insertado
        $id_libro = $conn->insert_id;

        // Insertar en la tabla asociado
        $sql_asociado = $conn->prepare("INSERT INTO asociado (id_libro) VALUES (?)");
        $sql_asociado->bind_param("i", $id_libro);
        $sql_asociado->execute();
    } elseif ($_POST['accion'] == 'baja') {
        // Eliminar libro de la tabla libros
        $sql = $conn->prepare("DELETE FROM libros WHERE id_libro = ?");
        $sql->bind_param("i", $id_libro);
        $sql->execute();
    } elseif ($_POST['accion'] == 'modificacion') {
        // Modificar libro en la tabla libros
        $sql = $conn->prepare("UPDATE libros SET titulo = ?, anio_publicacion = ?, genero = ?, cantidad = ? WHERE id_libro = ?");
        $sql->bind_param("sssii", $titulo, $anio_publicacion, $genero, $cantidad, $id_libro);
        $sql->execute();
    }
}

// Si se selecciona un libro para editar, obtener sus datos.
if (isset($_GET['id_libro'])) {
    $id_libro = $_GET['id_libro'];
    $sql = $conn->prepare("SELECT * FROM libros WHERE id_libro = ?");
    $sql->bind_param("i", $id_libro);
    $sql->execute();
    $resultado_libro = $sql->get_result();
    $libro = $resultado_libro->fetch_assoc();
} else {
    $libro = null;
}

$sql_libros = "SELECT * FROM libros";
$resultado = $conn->query($sql_libros);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Libros</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Gestión de Libros</h1>
    </header>

    <nav>
        <ul>
            <li><a href="../index.php">Inicio</a></li>
            <li><a href="./consulta_libros.php">Libros Disponibles</a></li>
        </ul>
    </nav>

    <h2>Agregar / Modificar / Eliminar Libro</h2>
    <form method="post" action="abm_libros.php">
        <label for="titulo">Título:</label>
        <input type="text" name="titulo" value="<?= $libro ? $libro['titulo'] : '' ?>" required><br>

        <label for="anio_publicacion">Año de Publicación:</label>
        <input type="date" name="anio_publicacion" value="<?= $libro ? $libro['anio_publicacion'] : '' ?>" required><br>

        <label for="genero">Género:</label>
        <input type="text" name="genero" value="<?= $libro ? $libro['genero'] : '' ?>" required><br>

        <label for="cantidad">Cantidad:</label>
        <input type="number" name="cantidad" value="<?= $libro ? $libro['cantidad'] : '' ?>" required><br>

        <!-- Campo oculto para enviar el ID del libro -->
        <input type="hidden" name="id_libro" value="<?= $libro ? $libro['id_libro'] : '' ?>">

        <!-- Botones para las diferentes acciones -->
        <input type="submit" name="accion" value="alta">
        <input type="submit" name="accion" value="modificacion">
        <input type="submit" name="accion" value="baja">
    </form>

    <h2>Libros Existentes</h2>
    <table>
        <thead>
            <tr>
                <th>ID Libro</th>
                <th>Título</th>
                <th>Año de Publicación</th>
                <th>Género</th>
                <th>Cantidad</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $resultado->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id_libro'] ?></td>
                    <td><?= $row['titulo'] ?></td>
                    <td><?= $row['anio_publicacion'] ?></td>
                    <td><?= $row['genero'] ?></td>
                    <td><?= $row['cantidad'] ?></td>
                    <td>
                        <!-- Botón para eliminar el libro (actualiza el formulario con el ID) -->
                        <form method="post" action="abm_libros.php">
                            <input type="hidden" name="id_libro" value="<?= $row['id_libro'] ?>">
                            <input type="submit" name="accion" value="baja" onclick="return confirm('¿Seguro que deseas eliminar este libro?');">
                        </form>
                        <!-- Enlace para modificar el libro (redirige con el ID del libro) -->
                        <a href="abm_libros.php?id_libro=<?= $row['id_libro'] ?>">Modificar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
