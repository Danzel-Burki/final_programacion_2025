document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    
    form.addEventListener("submit", function(e) {
        // Agregar validaciones aquí si es necesario
        alert("Formulario enviado correctamente");
    });
});
